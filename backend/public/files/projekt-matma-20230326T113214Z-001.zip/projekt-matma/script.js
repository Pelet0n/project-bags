const button = document.querySelector('#start')
const levels = document.querySelectorAll('label')
const gameContainer = document.querySelector('.game-container')

let selectedLevel = "easy"


for(const level of levels){
    level.addEventListener("click",()=>{
        selectedLevel = level.dataset.value
    })
}




button.addEventListener("click",startGame)


function startGame(){
    gameContainer.remove()
}