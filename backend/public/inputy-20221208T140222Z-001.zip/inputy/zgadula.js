const slowa = ['zdanie','szkoła','laptop','krzesło','tablica','żaba','stół','szyby','nauczyciel','uczniowie','praca','plakaty']
let punkty = 0

function word_game(){
    let slowo = slowa[Math.floor(Math.random() * slowa.length)]

    let shuffled = slowo.split('')

    for(let i = 0;i < shuffled.length;i++){
        const randomIndex = Math.floor(Math.random() * shuffled.length);

        [shuffled[i], shuffled[randomIndex]] = [shuffled[randomIndex], shuffled[i]];
    }

    document.getElementById("game-input").addEventListener("keyup",(e)=>{
        if(e.target.value == ''){
            return 
        }
        if(e.target.value.toLowerCase() == slowo){
            e.target.value = ''
            punkty += 1
            word_game()
        }
    })
    
    document.getElementById("game").innerHTML = shuffled.join('')
    document.getElementById("points").innerHTML = `Liczba punktów: ${punkty}`

}



window.addEventListener("DOMContentLoaded",word_game)

