const form = document.querySelector("form")
const valueP = document.getElementsByTagName("ul")

form.addEventListener("submit",e=>{
    e.preventDefault()

    const formData = new FormData(form)

    for(let [key,value] of formData.entries()){
        if(key = 'password'){
            value
        }

        valueP.innerHTML = `<li>${key} : ${value}</li>`
    }
    
})