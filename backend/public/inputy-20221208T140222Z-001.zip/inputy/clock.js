
function setTime(value=null){

    const date = new Date()

    let time = value ? value.split(":") : null

    let seconds = value ? '00' : date.getSeconds()
    let minutes = value ? time[1] : date.getMinutes()
    let hours = value ? time[0] : date.getHours()

    document.getElementById("timer").innerHTML = `${hours}:${minutes < 10 && !value ? '0'+minutes : minutes}:${seconds}`
}





document.body.addEventListener("load",setTime())

function addTime(){
    let time = document.getElementById("timer").innerHTML
    
    let times = time.split(":")

    let intTimes = times.map(Number)

    let seconds = intTimes[2]
    let minutes = intTimes[1]
    let hours = intTimes[0]

    seconds += 1

    if(seconds > 59){
        seconds = 0
        minutes += 1
    }
    else if(minutes > 59){
        minutes = 0
        hours += 1
    }

    document.getElementById("timer").innerHTML = `${hours}:${minutes < 10 ? '0'+minutes : minutes}:${seconds < 10 ? '0'+seconds : seconds}`
    
}

setInterval(addTime,1000)


document.getElementById("timeInput").addEventListener("change",e=>{
    setTime(e.target.value + ':00')
})